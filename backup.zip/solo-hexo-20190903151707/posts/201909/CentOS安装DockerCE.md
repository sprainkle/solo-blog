title: CentOS 安装 Docker CE
date: '2019-09-03 14:49:10'
updated: '2019-09-03 15:04:42'
tags: [Linux, Docker, Centos7]
permalink: /centos7-install-docker
---
![](https://img.hacpai.com/bing/20171207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言
Docker 目前支持 CentOS 7 及以后的版本，内核要求至少为 3.10。
Docker 官网有安装步骤，本文只是记录一下，您也可以参考 [Get Docker CE for CentOS](https://docs.docker.com/install/linux/docker-ce/centos/)

## 准备工作
### 操作系统要求
CentOS 7 以后都可以安装 Docker 了，也可以确认一下。
```shell
$ uname -a
Linux izwz94664y88ugul9l0nbgz 3.10.0-693.2.2.el7.x86_64 #1 SMP Tue Sep 12 22:26:13 UTC 2017 x86_64 x86_64 x86_64 GNU/Linux
```

### 确认源 centos-extra
Docker 需要用到 centos-extra 这个源，如果关闭了，需要重启启用，使用 `yum  repolist` 查看，如下图，则代表已启用（centos7 默认是启用的）。
![检查是否启用 centos-extra](https://upload-images.jianshu.io/upload_images/6082182-3635ebaabd4cce26.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

若未启用，修改文件 `/etc/yum.repos.d/CentOS-Base.repo`即可，设置 `enabled=1`，如下图：
![启用 centos-extra](https://upload-images.jianshu.io/upload_images/6082182-b507892dcc5ffb6e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
 
更多可参考：[How to enable or disable repositories in CentOS](https://www.unixmen.com/enable-disable-repositories-centos/)。

### 卸载旧版本
旧版本的 Docker 被叫做 docker 或 docker-engine，如果安装了旧版本的 Docker ，则需要卸载掉它。
```shell
$ sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
```

## 安装
### 安装依赖包
```shell
$ sudo yum install -y yum-utils \
           device-mapper-persistent-data \
           lvm2
```
### 添加 yum 软件源
```
# 鉴于国内网络问题，建议使用国内源
$ sudo yum-config-manager \
    --add-repo \
    https://mirrors.ustc.edu.cn/docker-ce/linux/centos/docker-ce.repo

# 也可以使用官方源
$ sudo yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo
```

### 安装 Docker CE
更新 yum 软件源缓存，并安装 docker-ce。
```shell
$ sudo yum makecache fast
$ sudo yum install docker-ce
```
至此，Docker 已经安装完成了。

### 启动 Docker CE
```shell
$ sudo systemctl start docker

# 开机启动
$ sudo systemctl enable docker
``` 

### 加入 docker 用户组
默认情况下，`docker` 命令会使用 [Unix socket](https://en.wikipedia.org/wiki/Unix_domain_socket) 与 `Docker` 引擎通讯。而只有 `root` 用户和 `docker` 组的用户才可以访问 `Docker` 引擎的 `Unix socket`。出于安全考虑，一般 Linux 系统上不会直接使用 `root` 用户。因此，更好地做法是将需要使用 `docker` 的用户加入 `docker` 用户组。

```shell
# $USER 为当前登录的用户
$ sudo usermod -aG docker $USER
```
退出当前终端并重新登录，进行如下测试。

### 测试 Docker 是否安装正确
```shell
$ docker run hello-world
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
ca4f61b1923c: Pull complete
Digest: sha256:be0cd392e45be79ffeffa6b05338b98ebb16c87b255f48e297ec7f98e123905c
Status: Downloaded newer image for hello-world:latest
...
```
若能正常输出类似以上信息，则说明安装成功。

## 扩展
### 镜像加速
鉴于国内网络问题，后续拉取 Docker 镜像十分缓慢，建议安装 `Docker` 之后配置国内镜像加速。

Docker 官方和国内很多云服务商都提供了国内加速器服务，例如：
*   [Docker 官方提供的中国 registry mirror](https://docs.docker.com/registry/recipes/mirror/#use-case-the-china-registry-mirror)：https://registry.docker-cn.com
*   [七牛云加速器](https://kirk-enterprise.github.io/hub-docs/#/user-guide/mirror)：https://reg-mirror.qiniu.com/

这里以 `Docker` 官方加速器 https://registry.docker-cn.com 为例进行介绍，在 `/etc/docker/daemon.json` 中写入如下内容（如果文件不存在请新建该文件）：
```json
{
  "registry-mirrors": [
    "https://registry.docker-cn.com"
  ]
}
```
之后重新启动服务:
```shell
$ sudo systemctl daemon-reload
$ sudo systemctl restart docker
```

### 安装指定版本
如果想安装指定版本的 Docker，可以查看一下版本并安装。
```shell
$ yum list docker-ce --showduplicates | sort -r
Loading mirror speeds from cached hostfile
Loaded plugins: fastestmirror
Installed Packages
docker-ce.x86_64            3:19.03.1-3.el7                    docker-ce-stable
docker-ce.x86_64            3:19.03.1-3.el7                    @docker-ce-stable
docker-ce.x86_64            3:19.03.0-3.el7                    docker-ce-stable
...
docker-ce.x86_64            18.06.3.ce-3.el7                   docker-ce-stable
docker-ce.x86_64            18.06.2.ce-3.el7                   docker-ce-stable
...
```

第二列为版本号，出现了两种格式，`3:version-3.el7`、`version-3.el7`，版本号只需截取 `version` 部分，如：`3:19.03.1-3.el7` 截取的是 `19.03.1`，`18.06.3.ce-3.el7` 截取的是 `18.06.3.ce`。

安装指定版本，可使用 `sudo yum install docker-ce-<VERSION STRING>`，其中 `VERSION STRING` 为版本号：
```shell
# 例如安装版本 18.06.3.ce
$ sudo yum install docker-ce-18.06.3.ce
```

### 添加内核参数
默认配置下，如果在使用命令 `docker info` 时看到下面的这些警告信息：
```
WARNING: bridge-nf-call-iptables is disabled
WARNING: bridge-nf-call-ip6tables is disabled
```
解决方法：
```shell
$ sudo vim /etc/sysctl.conf
```
添加如下内容：
```conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```

然后重新加载 sysctl.conf 即可：
```shell
$ sudo sysctl -p
```

## 参考链接
[https://docs.docker.com/install/linux/docker-ce/centos/](https://docs.docker.com/install/linux/docker-ce/centos/)
[https://www.unixmen.com/enable-disable-repositories-centos/](https://www.unixmen.com/enable-disable-repositories-centos/)

